/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package game;

/**
 *
 * @author xavi
 */
class Reglas {
    public enum Status { DRAW, RUNNING, WINNER }
    protected Taboleiro table;
    protected int turno;
    protected Status status;
    
    public Reglas(int filas, int columnas) {
        table=new Taboleiro(filas,columnas);
    }

    Taboleiro taboleiro() {
        return table;
    }
    
    void reset() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    boolean move(Movemento m) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    int turno() {
        return turno;
    }
    
    Status status() {
        return this.status;
    }
    
}
