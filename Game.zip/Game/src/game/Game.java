/*
Estás a desenvolver un xogo de mesa en Java no que dous xogadores compiten por realizar movementos 
nun taboleiro de nxm ata que un gañe ou se produza un empate. Debes implementar as clase necesarias 
para modelar os elementos esenciais do xogo dun xeito flexible e reutilizable.

O obxectivo é deseñar estas clases de forma que se poidan aplicar a diferentes tipos de xogos de mesa 
(por exemplo, Xadrez, Damas ou Tres en Raia), con cambios mínimos para cada xogo.

Requisitos do Problema
Cando un xogador realiza un Movemento, este movemento debe ser verificado segundo as regras do xogo,
si o movemento é conforme as regras se poderá levar a cabo sobre o taboleiro conforme as regras,  modificando o seu estado.
Unha vez que o taboleiro modifica o seu estado, ten que verificar segundo as regras o estado do xogo,
que pode ser que o xogo continúa, que finaliza con empate ou que finaliza cun gañador.
Neste ultimo caso debe ser posible obter o gañador.

Condicións e Recomendacións
Encapsulamento e Flexibilidade: Cada clase debe ser autónoma e traballar cunha interface 
clara e reusable. Debedes protexer axeitadamente os atributos das clases para que non se poda alterar o seu estado dende fora sen control.

Validación e Excepcións: Asegúrate de incluír validación nas posicións e movementos para evitar erros de indexación e outros problemas. 
Selecciona e controla as excepcións axeitadas no seu caso.

Programa Final
Realiza un xogo do tres en raia utilizando o deseñado. Neste xogo, cada xogador irá escollendo a posición onde colocará a súa ficha por turnos e realizando a xogada ata que un dos dous gañe ou se encha o taboleiro.

O obxectivo deste deseño é que o deseño de clases que poidan reutilizarse 
e configurarse para calquera outro xogo de mesa modificando unicamente as regras específicas para cada xogo
 */


/** Análise
 * Clases:
 *          Xogador     - Entidade que xoga
 *              - nick   - Identificador do xogador
 *              - cor  - Grupo de fichas (brancas, negras, azuis....ou outro tipo de identificador)
 * 
 *              Movemento move()
 * 
 * 
 *          Ficha       - Ficha que forma parte do xogo 
 *              - nome
 *              - cor 
 *          
 *          Taboleiro   - Estado do Xogo
  *             - tabla[alto][ancho] de Ficha
  * 
  *             Ficha get(int f,int c);             - Obten a ficha que temos en f,c
  *             void put(int f, int c, Ficha f);    - Poñemos a ficha f en f,c
  *             void show();                        - Visualiza o tabaoleiro na pantalla
 * 
 *          Reglas      - Reglas do Xogo
 *              - Taboleiro - Taboleiro
 *              - turno
 * 
 *              void move(Movemento m)              - Efectua o movemento conforme as regras e cambia o turno
 *              void status()                       - Retorna o estado do xogo
 *              void reset()                        - Establece o estado inicial do xogo
 *              int turno()                         - Obten o xogador en turno
 *      
 * 
 *          Movemento   - Xogada creada polo xogador
 *              - Xogador
 * 
 *              construtor
 
 * 
 * 
 *          Algoritmo do Xogo
 *              - O xogo ten uns xogadores (xogadores[]), e unhas Regras (regras)
 *              - Limpar o tabolario, e establecer o turno
 *              
 *              facer
    *              - Movemento m=xogadpr[turno].move() - O xogador en turno crea o Movemento m
 *                  - regras.move(m) - Segundo as regras efectuamos a xogada.
 *                  - estado=regras.status()  obtemos o estado do xogo
 *              mentras(estado != tablas && estado !=gañador)
 *              Si o estado e tablas, mensaxe "Tablas !!!"
 *              Se non                mensaxe "Noraboa " xogador[turno], eres o gañador"
 * 
 *              
 * 
 * 
 */
package game;

/**
 *
 * @author xavi
 */
public class Game {
    private Reglas reglas;
    private Xogador[] xogadores;
    
    public Game(Reglas reglas,Xogador[] xogadores) {
        this.reglas=reglas;
        this.xogadores=xogadores;
    }
    
    public void start() {
        Reglas.Status state=Reglas.Status.RUNNING;
        Taboleiro table=reglas.taboleiro();
        
        reglas.reset();
        try {
            do {
                table.show();
                Movemento m=xogadores[reglas.turno()].move();
                if (reglas.move(m)) state=reglas.status();
                else                System.out.println(xogadores[reglas.turno()]+": xogada errónea, inténtao de novo");
            } while(state==Reglas.Status.RUNNING);
            table.show();
            if (state==Reglas.Status.DRAW) System.out.println("Honroso Empate !!");
            else                    System.out.println("Noraboa "+xogadores[reglas.turno()]+" eres o gañador");
        } catch(CancelException e) {
            System.out.println(e.getMessage());
        }
    }
    
    
    
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Xogador[] xogadores=new XogadorPut[2];
        Reglas reglas=new ReglasTresEnRaia();
        xogadores[0]=new XogadorPut("Juan","O");
        xogadores[1]=new XogadorPut("Maria","X");
        Game game=new Game(reglas,xogadores);
        game.start();
    }

}
