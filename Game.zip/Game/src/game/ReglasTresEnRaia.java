package game;

/**
 *
 * @author xavi
 */
public class ReglasTresEnRaia extends Reglas {
   
    public ReglasTresEnRaia() {
        super(3,3);
        reset();
    }
    
    @Override
    final void reset() {
        turno=0;
        table.clear();
    }

    @Override
    boolean move(Movemento m) {
        boolean ok=true;
        MovementoPut mp=(MovementoPut) m;
        int fila=mp.getFila();
        int columna=mp.getColumna();
        
        try {
            if (table.get(fila,columna)!=null) ok=false;
            else {
                Ficha ficha= new Ficha("Ficha 3 Raia",m.getXogador().getCor());
                table.put(fila,columna,ficha);
                this.status=checkStatus();
                if (status==Status.RUNNING) turno=1-turno;
            }
        } catch(IllegalMove e) {
            ok=false;
        }
        return ok;
    }

    Status checkStatus() {
        Status state=Status.RUNNING;
        String ficha0=null;
        String ficha1=null;
        String ficha2=null;
        boolean full=true;
        try {
            // Temos 3 raia ?
            /*
                        XXX
                        XXX
                        XXX
            */
            
            // Comprobar horizontal
            
            for(int f=0;f<3;f++) {
                Ficha fcha=table.get(f,0);
                if (fcha==null) full=false;
                else {
                    ficha0=fcha.getCor();
                    fcha=table.get(f,1);
                    if (fcha==null) full=false;
                    else {
                        ficha1=fcha.getCor();
                        fcha=table.get(f,2);
                        if (fcha==null) full=false;
                        else ficha2=fcha.getCor();
                    }
                    if (ficha0.equals(ficha1) && ficha0.equals(ficha2)) state=Status.WINNER;
                }
            }
            if (state==Status.RUNNING) {
                // Comprobar vertical
                for(int c=0;c<3;c++) {
                    Ficha fcha0=table.get(0,c);
                    Ficha fcha1=table.get(1,c);
                    Ficha fcha2=table.get(2,c);
                    if (fcha0!=null && fcha1!=null&& fcha2!=null) {
                        ficha0=fcha0.getCor();
                        ficha1=fcha1.getCor();
                        ficha2=fcha2.getCor();
                        if (ficha0.equals(ficha1) && ficha0.equals(ficha2)) state=Status.WINNER;
                    }
                }
            }

            // Comprbar diagonal
            if (state==Status.RUNNING) {
                Ficha fcha0=table.get(0,0);
                Ficha fcha1=table.get(1,1);
                Ficha fcha2=table.get(2,2);
                if (fcha0!=null && fcha1!=null&& fcha2!=null) {    
                    ficha0=fcha0.getCor();
                    ficha1=fcha1.getCor();
                    ficha2=fcha2.getCor();
                    if (ficha0.equals(ficha1) && ficha0.equals(ficha2)) state=Status.WINNER;
                }
                fcha0=table.get(0,2);
                fcha1=table.get(1,1);
                fcha2=table.get(2,0);
                if (fcha0!=null && fcha1!=null&& fcha2!=null) {    
                    ficha0=fcha0.getCor();
                    ficha1=fcha1.getCor();
                    ficha2=fcha2.getCor();
                    if (ficha0.equals(ficha1) && ficha0.equals(ficha2)) state=Status.WINNER;
                }
            }
            if (state==Status.RUNNING && full) state=Status.DRAW; 
        } catch(IllegalMove e) {
        }
        return state;
    }
}
