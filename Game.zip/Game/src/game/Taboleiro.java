/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package game;

/**
 *
 * @author xavi
 */
class Taboleiro {
    private Ficha[][] table;
    
    public Taboleiro(int filas,int columnas) {
        table=new Ficha[filas][columnas];
    }

    
    public void put(int f,int c, Ficha ficha) throws IllegalMove {
        try {
            table[f][c]=ficha;
        } catch(IndexOutOfBoundsException e) {
            throw new IllegalMove("Posicion fora do tableiro");
        }
    }
    
    public Ficha get(int f,int c) throws IllegalMove {
        try {
            return table[f][c];
        } catch(IndexOutOfBoundsException e) {
            throw new IllegalMove("Posicion fora do tableiro");
        }
    }
    
    /**
     * Amosa o taboleiro na pantalla
     */
    public void show() {
        Ficha ficha;
        for(int f=0;f<table.length;f++) {
            for(int c=0;c<table[0].length;c++) {
                ficha=table[f][c];
                if (ficha!=null) System.out.print(ficha.getCor());
                else           System.out.print(" ");
            }
            System.out.println();
        }
    }
    
    public void clear() {
        for(int f=0;f<table.length;f++) {
            for(int c=0;c<table[0].length;c++) {
                table[f][c]=null;
            }
            System.out.println();
        }
    }
}
