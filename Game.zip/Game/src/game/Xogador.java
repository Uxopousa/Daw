package game;

class Xogador {
    protected final String cor;
    protected final String nick;

    Xogador(String nick, String cor) {
        this.cor=cor;
        this.nick=nick;
    }

    public String getCor() {
        return cor;
    }

    public String getNick() {
        return nick;
    }
    
    @Override
    public String toString() {
        return this.nick;
    }

    Movemento move() throws CancelException {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
