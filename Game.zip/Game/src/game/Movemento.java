package game;

class Movemento {
    private final Xogador xogador;
    
    public Movemento(Xogador xogador) {
        this.xogador=xogador;
    }

    public Xogador getXogador() {
        return xogador;
    }
}
