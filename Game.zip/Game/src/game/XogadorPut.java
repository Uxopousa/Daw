/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package game;

import java.util.Scanner;

/**
 *
 * @author xavi
 */
public class XogadorPut extends Xogador {
    public XogadorPut(String nick,String cor) {
        super(nick,cor);
    }
    
    @Override
    Movemento move() throws CancelException {
        boolean ok=true;
        int fila=0;
        int columna=0;
        Scanner scn=new Scanner(System.in);
        do {
            try {
                System.out.println("Turno de "+nick);
                System.out.print("Fila (numero negativo para abandoar xogo): ");
                fila=Integer.parseInt(scn.nextLine());
                if (fila<0) throw new CancelException("Xogo abandoado");
                System.out.print("Columna (numero negativo abandoar xogo): ");
                columna=Integer.parseInt(scn.nextLine());
                if (columna<0) throw new CancelException("Xogo abandoado");
            } catch(NumberFormatException e) {
                System.out.println("So Numeros >= 0 ");
                ok=false;
            }
        } while(!ok);
        return new MovementoPut(this,fila,columna);
    }
}
