package ecuacioncomplex;

import numbers.Complex;
import java.util.NoSuchElementException;

public class Ecuacion {
    private double a;
    private double b;
    private double c;
    
    public Ecuacion(double a,double b, double c) {
        this.a=a;
        this.b=b;
        this.c=c;
    }
    
    public Complex[] resolve()  {
      Complex[] solucion=null;  // Sin solucions
      
      if (a==0) {
         if (b==0) {
            if (c==0) throw new IllegalStateException("Infinitas Solucions");
            else      throw new NoSuchElementException("A ecuación non ten solución");
         } else {
            /**
               solucion=new int[1];
               solucion[0]=-b/c;
            */
            Complex sc=new Complex(-c/b,0);
            solucion=new Complex[] { sc };
         }
      } else {
        double disc=b*b-4*a*c;
        if (disc==0) solucion=new Complex[] {new Complex(-b/2*a) };
        else {
            double radix=Math.sqrt(Math.abs(disc));
            if (disc > 0)
                solucion=new Complex[] { new Complex((-b+radix)/2.0*a), new Complex((-b-radix)/2.0*a) };
            else
                solucion=new Complex[] { new Complex(-b/2.0*a , radix/2.0*a), new Complex(-b/2.0*a , -radix/2.0*a) };
        }
      }
      return solucion;
   }
}
