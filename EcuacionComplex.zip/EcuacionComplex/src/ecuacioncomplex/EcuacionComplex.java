package ecuacioncomplex;

import numbers.Complex;
import java.util.Scanner;
import java.util.NoSuchElementException;

/**
 *
 * @author xavi
 */
public class EcuacionComplex {
   public static void main(String[] args) {
      Scanner scn=new Scanner(System.in);
      double a;
      double b;
      double c;
   
      try {
         System.out.print("Valor de A: ");
         a=Double.parseDouble(scn.nextLine());
      
         System.out.print("Valor de B: ");
         b=Double.parseDouble(scn.nextLine());

         System.out.print("Valor de C: ");
         c=Double.parseDouble(scn.nextLine());

         // Si lanza unha Exception, infinitas solucións (calquera valor de x e solución).
         // Si retorna null, non ten solucións.
         // Si o array devolto ten unha lonxitude de 1, unha solución, si ten unha lonxitude de 2 duas solucións     
         Ecuacion ecuacion=new Ecuacion(a,b,c);
         Complex[] sol=ecuacion.resolve();
         if (sol==null) System.out.println("Sen solucións");
         else {
            for(int idx=0;idx<sol.length;idx++) {
               System.out.printf("Solucion %d: x=%s\n",(idx+1),sol[idx]);
            }
         }
      
      } catch(NumberFormatException e) {
         System.out.println("Debes introducir valores numéricos");
      } catch(IllegalStateException e) {
         System.out.println(e.getMessage());
         System.out.println("Todo valor de x e unha solución a ecuación");
      } catch(NoSuchElementException e) {
        System.out.println(e.getMessage());
        System.out.println("Ningún valor de x e unha solución a ecuación");
      }
   }
   
    
}
