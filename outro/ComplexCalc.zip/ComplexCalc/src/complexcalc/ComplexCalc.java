package complexcalc;

import numbers.Complex;
import utils.CancelException;
import utils.Input;

/**
 *
 * @author xavi
 */
public class ComplexCalc {

    public static void main(String[] args) {
        enum Options { SUMA, RESTA, MULTIPLICACION, DIVISION, SAIR }
        Options op=null;
    
        try {
            do {
                System.out.println("Calculadora de Números Complexos");
                System.out.println("--------------------------------");
                System.out.println("1.- Suma de Complexos");
                System.out.println("2.- Resta de Complexos");
                System.out.println("3.- Multiplicación de Complexos");
                System.out.println("4.- División de Complexos");
                System.out.println("5.- Pechar a Calculadora");
                int num=Input.integer("Elixe opcion");
                try {
                    op=Options.values()[num-1];
                    switch(op) {
                        case SUMA -> {
                            System.out.println("\nSuma de Números Complexos");
                            Complex c1=Input.complex("Introduce o primeiro número");
                            Complex c2=Input.complex("Introduce o segundo número");
                            Complex result=c1.add(c2);
                            System.out.println("\nO Resultado é:");
                            System.out.println("\t("+c1+") + ("+c2+") = "+result);
                            Input.pause("\nPara seguir pulsa Enter.");
                        }
                        case RESTA -> {
                            System.out.println("\nResta de Números Complexos");
                            Complex c1=Input.complex("Introduce o primeiro número");
                            Complex c2=Input.complex("Introduce o segundo número");
                            Complex result=c1.subtract(c2);
                            System.out.println("\nO Resultado é:");
                            System.out.println("\t("+c1+") - ("+c2+") = "+result);
                            Input.pause("\nPara seguir pulsa Enter.");
                        }
                        case MULTIPLICACION -> {
                            System.out.println("\nMultiplicación de Números Complexos");
                            Complex c1=Input.complex("Introduce o primeiro número");
                            Complex c2=Input.complex("Introduce o segundo número");
                            Complex result=c1.multiply(c2);
                            System.out.println("\nO Resultado é:");
                            System.out.println("\t("+c1+") * ("+c2+") = "+result);
                            Input.pause("\nPara seguir pulsa Enter.");
                        }
                        case DIVISION -> {
                            System.out.println("\nDivisión de Números Complexos");
                            Complex c1=Input.complex("Introduce o primeiro número");
                            Complex c2=Input.complex("Introduce o segundo número");
                            Complex result=c1.subtract(c2);
                            System.out.println("\nO Resultado é:");
                            System.out.println("\t("+c1+") / ("+c2+") = "+result);
                            Input.pause("\nPara seguir pulsa Enter.");
                        }
                    }
                } catch(CancelException e) {
                    System.out.println(e.getMessage());
                }
                System.out.println();
            } while(op!=Options.SAIR);
        } catch(CancelException e) {
            System.out.println(e.getMessage());
            System.out.println("Abandoando o programa");
        }
    }
    
}
