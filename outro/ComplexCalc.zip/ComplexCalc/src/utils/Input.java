
package utils;

import java.util.Scanner;
import numbers.Complex;

public class Input {
    private static final String CANCELSTR="*";
    private static Scanner scn=new Scanner(System.in);
    
    /**
     * Para poder reutilizar esta operación en posibles diferentes entradas de datos...
     * ( string, double, dni, email, diasemana, date, time .... )
     * aforrando código
     * 
     * @param msg
     * @return
     * @throws CancelException 
     */
    private static String getstr(String msg) throws CancelException {
        System.out.print(msg+" ("+CANCELSTR+" para cancelar): ");
        String input=scn.nextLine();
        if (input.equals(CANCELSTR)) throw new CancelException();
        return input;
    }
    
    
    public static Complex complex(String msg) throws CancelException {
        double real;
        double imaginary;
        Complex complex=null;
        
        do {
            try {
                System.out.println(msg+":");
                String strreal=getstr("\tParte real");
                real=Double.parseDouble(strreal);
                String strimaginary=getstr("\tParte imaxinaria");
                imaginary=Double.parseDouble(strimaginary);
                complex=new Complex(real,imaginary);
            } catch(NumberFormatException e) {
                System.out.println("\t--> Debes introducir un valor numérico real");
            }
        } while(complex==null);
        return complex;
    }
    
    public static int integer(String msg,int min, int max) throws CancelException {
        boolean ok=false;
        int num=0;
        
        do {
            try {
                String strnum=getstr(msg);
                num=Integer.parseInt(strnum);
                if ((num<min) || (num>max)) {
                    System.out.println("\t--> O valor debe estar entre "+min+" e "+max+" (incluídos)");
                } else {
                    ok=true;
                }
            } catch(NumberFormatException e) {
                System.out.println("\t--> Debes introducir un valor numérico enteiro");
            }
        } while(!ok);
        return num;
    }
    
    public static int integer(String msg) throws CancelException {
        return integer(msg,Integer.MIN_VALUE,Integer.MAX_VALUE);
    }
    
    public static void pause(String msg) {
        System.out.print(msg);
        scn.nextLine();
    }
}
