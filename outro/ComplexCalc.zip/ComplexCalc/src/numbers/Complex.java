package numbers;

import java.text.DecimalFormat;

public class Complex {
    // Atributos que representan a parte real e imaxinaria do número complexo.
    private double real;
    private double imaginary;

    // Constructor principal
    public Complex(double real, double imaginary) {
        this.real = real;
        this.imaginary = imaginary;
    }
    
    
    // Constructor sen parte imaxinaria
    public Complex(double real) {
        this.real = real;
        this.imaginary = 0;
    }
    
    // Retorna a forma binómica dun número complexo
    public double[] binomic() {
        return new double[] { real, imaginary };
    }

    // Método para sumar dous números complexos
    public Complex add(Complex other) {
        return new Complex(this.real + other.real, this.imaginary + other.imaginary);
    }

    // Método para restar dous números complexos
    public Complex subtract(Complex other) {
        return new Complex(this.real - other.real, this.imaginary - other.imaginary);
    }

    // Método para multiplicar dous números complexos
    public Complex multiply(Complex other) {
        double realPart = this.real * other.real - this.imaginary * other.imaginary;
        double imaginaryPart = this.real * other.imaginary + this.imaginary * other.real;
        return new Complex(realPart, imaginaryPart);
    }

    // Método para dividir dous números complexos
    public Complex divide(Complex other) {
        double denominator = other.real * other.real + other.imaginary * other.imaginary;
        double realPart = (this.real * other.real + this.imaginary * other.imaginary) / denominator;
        double imaginaryPart = (this.imaginary * other.real - this.real * other.imaginary) / denominator;
        return new Complex(realPart, imaginaryPart);
    }

    // Método para calcular o módulo do número complexo
    public double modulus() {
        return Math.sqrt(this.real * this.real + this.imaginary * this.imaginary);
    }

    // Método para representar o número complexo como unha cadea
    @Override
    public String toString() {
        DecimalFormat numf = new DecimalFormat("#.####"); // Formato hasta 4 decimales, si no hay, se eliminan.

        if (imaginary==0) return Double.toString(real);
        else  if (imaginary > 0) {
            //return String.format("%.4f",real) + " + " + String.format("%.4f",imaginary) + "i";
            return numf.format(real) + " + " + numf.format(imaginary) + "i";

        } else {
            //return String.format("%.4f",real) + " - " + String.format("%.4f",-imaginary) + "i";
            return numf.format(real) + " - " + numf.format(-imaginary) + "i";
        }
    }
}
